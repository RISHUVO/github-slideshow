# COMP125-MidTerm

MidTerm Exam Template for COMP125 - Client-Side Web Development @ Centennial College
